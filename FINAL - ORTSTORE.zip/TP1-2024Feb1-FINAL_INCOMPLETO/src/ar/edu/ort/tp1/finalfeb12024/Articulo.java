package ar.edu.ort.tp1.finalfeb12024;

public class Articulo {

    private Empresa fabricante;
    private String codigo;
    private Calidad calidad;

    // Completar con lo que falte...

    public Articulo(Empresa emp, String cod, Calidad c) throws Exception {
		setFabricante(emp);
		setCodigo(cod);
		setCalidad(c);
	}
    
    private void setFabricante(Empresa emp) throws Exception {
    	if (emp == null) {
			throw new Exception("El fabricante no puede ser nulo");
		}
		this.fabricante = fabricante;
	}

	private void setCodigo(String codigo) throws Exception {
		if (codigo == null || codigo.isBlank()) {
			throw new Exception("El c�digo no puede ser nulo ni vac�o");
		}
		this.codigo = codigo;
	}

	private void setCalidad(Calidad calidad) throws Exception {
		if (calidad == null) {
			throw new Exception("La calidad no puede ser nula");
		}
		this.calidad = calidad;
	}

	@Override
    public String toString() {
        return codigo;
    }

	public boolean esFragil() {
		return this.calidad.ordinal() == Calidad.values().length - 1;
	}
}