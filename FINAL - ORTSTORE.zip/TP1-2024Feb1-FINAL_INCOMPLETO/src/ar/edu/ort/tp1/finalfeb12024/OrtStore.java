package ar.edu.ort.tp1.finalfeb12024;

import ar.edu.ort.tp1.tdas.implementaciones.ColaNodos;

public class OrtStore {

    private static final int CANT_COMPARTIMENTOS = 5;
    // Completar atributo/s faltante/s
    private Compartimento[] compartimentos;
    private ColaNodos<Articulo> listaPendientes;

    /**
     * TODO Debe iniciar las estructuras capaces de albergar los productos y los compartimentos.
     * Adem�s, debe crear los compartimentos: cuatro de tipo com�n y tres de tipo fr�gil.
     */
    public OrtStore() {
    	compartimentos = new Compartimento[] { new CompartimentoComun(), new CompartimentoComun(), new CompartimentoComun(), 
    			new CompartimentoFragil(), new CompartimentoFragil() };
    	listaPendientes = new ColaNodos<>();
    }    
    
	/**
     * Debe agregar el artículo a la colección de pendientes.
     * @param articulo El articulo a agregar
	 * @throws Exception 
     */
    public void ingresarArticuloAPendientes(Articulo articulo) throws Exception {
        if (articulo == null) {
			throw new Exception("***ERROR: El artículo ingresado es nulo***");
		}
        listaPendientes.add(articulo);
    }
    
    /**
     * TODO Debe tomar a todos y cada uno de los articulos de la coleccion de pendientes y 
     * guardar a cada uno en el primer compartimento que lo pueda guardar de acuerdo con las 
     * condiciones de cada uno. Si no hubiera lugar en ningun compartimento, tratar tal
     * situacion con una excepcion.
     */
    public void ingresarArticulosACompartimentos() throws Exception{
       while (!listaPendientes.isEmpty()) {
    	   Articulo a = listaPendientes.remove();
    	   ubicarArticulo(a);
       }
    }
    
    private void ubicarArticulo(Articulo a) throws Exception{
    	boolean seGuardo = false;
    	if (!a.esFragil()) {
    		int com = 0;
			while (!seGuardo && com < compartimentos.length - 2) {
				seGuardo = compartimentos[com].ubicarArticulo(a);
				com++;
			}
		} else {
			int comFragil = 3;
			while (!seGuardo && comFragil < compartimentos.length) {
				seGuardo = compartimentos[comFragil].ubicarArticulo(a);
				comFragil++;
			}
		}
		
	}

	/**
     * TODO Debe retornar cual es la empresa (suponer unica) que posee mayor cantidad de articulos
     * con la calidad recibida como parametro.
     * @param c La calidad a buscar
     * @return cual es la empresa (suponer unica) que posee mayor cantidad de articulos con la
     * calidad recibida como parametro.
     */
    public Empresa empresaConMasArticulosDeCalidad(Calidad c) {
        
    }    
    
    /**
     * TODO Hacer que todo Compartimento sea Mostrable, para lograr que
     * se muestre la salida esperada tras la ya realizada llamada a este
     * metodo en el main.
     */
    public void mostrarCompartimentos() {
    	for (int i = 0; i < compartimentos.length; i++) {
			System.out.printf("Compartimento #%d:\n", (i+1));
			compartimentos[i].mostrar();
		}
    }

}