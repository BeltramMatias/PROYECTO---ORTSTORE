package ar.edu.ort.tp1.finalfeb12024;

public interface Mostrable {
	void mostrar();
}
