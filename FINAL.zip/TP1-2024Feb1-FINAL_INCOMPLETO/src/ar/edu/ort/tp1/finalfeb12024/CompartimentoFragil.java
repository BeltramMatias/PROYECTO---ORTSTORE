package ar.edu.ort.tp1.finalfeb12024;

public class CompartimentoFragil extends Compartimento {

	private static final int ESPACIOS = 2;
	private Articulo[][] articulosFragiles;
	
	public CompartimentoFragil() {
		articulosFragiles = new Articulo[ESPACIOS][ESPACIOS];
	}
	
	@Override
	public void mostrar() {
		recorrerCompartimento();
	}

	private void recorrerCompartimento() {
		int fila = 0;
		while (fila < ESPACIOS) {
			int colum = 0;
			while (colum < ESPACIOS) {
				System.out.println(articulosFragiles[fila][colum]);
				colum++;
			}
			fila++;
		}
	}

	@Override
	protected boolean ubicarArticulo(Articulo a) {
		boolean sePuede = hayEspacio();
		if (a != null  && sePuede) {
			int[] pos = buscarEspacio();
			articulosFragiles[pos[0]][pos[1]] = a;
		}
		return sePuede;
	}
	
	private int[] buscarEspacio() {
		int[] pos = {-1, -1};
		int fila = 0;
		boolean seEncontro = false;
		while (!seEncontro && fila < ESPACIOS) {
			int colum = buscarEspacioEnFila(fila);
			seEncontro = colum < ESPACIOS;
			if (seEncontro) {
				pos = new int[] {fila, colum};
			}
			fila++;
		}
		
		return pos;
	}
	
	private int buscarEspacioEnFila(int fila) {
		int colum = 0;
		boolean seEncontro = false;
		while (!seEncontro && colum < ESPACIOS) {
			seEncontro = articulosFragiles[fila][colum] != null;
			if (!seEncontro) {
				colum++;
			}
		} 
		return colum;
	}

	/*
	 * Hago uso de este m�todo para ahorrarme una b�squeda en la matriz en el caso de que ya est� llena. Solo lo hago
	 * as� porque s� que los art�culos ser�n ubicados en el primer hueco disponible, recorriendo la matriz de izquierda
	 * a derecha, de arriba a abajo, ya que si fuese de otra manera este m�todo no servir�a.
	 * En el caso de que el �ltimo hueco de la matriz sea distinto de null, significa que la matriz ya est� completa
	 * y ya no pueden ubicarse m�s articulos.
	 */
	private boolean hayEspacio() {
		return articulosFragiles[ESPACIOS-1][ESPACIOS-1] == null;
	}
}
