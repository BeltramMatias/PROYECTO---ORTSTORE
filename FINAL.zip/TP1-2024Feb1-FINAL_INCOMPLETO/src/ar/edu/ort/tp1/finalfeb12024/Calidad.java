package ar.edu.ort.tp1.finalfeb12024;

public enum Calidad {

    BAJA,
    REGULAR,
    ALTA;

}