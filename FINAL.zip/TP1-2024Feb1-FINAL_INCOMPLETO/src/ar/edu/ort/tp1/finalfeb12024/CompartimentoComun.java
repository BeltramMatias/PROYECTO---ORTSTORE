package ar.edu.ort.tp1.finalfeb12024;

import ar.edu.ort.tp1.tdas.implementaciones.PilaNodos;

public class CompartimentoComun extends Compartimento {

	private PilaNodos<Articulo> articulosComunes;
	
	public CompartimentoComun() {
		articulosComunes = new PilaNodos<>(3);
	}
	
	@Override
	public void mostrar() {
		recorrerCompartimiento();
	}

	private void recorrerCompartimiento() {
		PilaNodos<Articulo> aux = new PilaNodos<>();
		while (!articulosComunes.isEmpty()) {
			Articulo a = articulosComunes.pop();
			System.out.println(a);
			aux.push(a);
		}
		acomodarArticulos(aux, articulosComunes);
	}

	private void acomodarArticulos(PilaNodos<Articulo> aux, PilaNodos<Articulo> articulosComunes) {
		while (!aux.isEmpty()) {
			articulosComunes.push(aux.pop());
		}
	}

	@Override
	protected boolean ubicarArticulo(Articulo a) {
		boolean sePuede = !articulosComunes.isFull();
		if (a != null && sePuede) {
			articulosComunes.push(a);
		}
		return sePuede;
	}

}
