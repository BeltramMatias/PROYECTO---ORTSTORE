package ar.edu.ort.tp1.finalfeb12024;

public abstract class Compartimento implements Mostrable{

	protected abstract boolean ubicarArticulo(Articulo a);

}
